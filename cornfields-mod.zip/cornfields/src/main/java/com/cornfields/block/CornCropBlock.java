package com.cornfields.block;

import com.cornfields.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** ذرة: 5 مراحل (0-4)، كل مرحلة يومان (48000 تك). على التربة المسمدة تنمو بضعف السرعة. */
public class CornCropBlock extends Block implements BonemealableBlock {
    public static final int MAX_AGE = 4;
    public static final IntegerProperty AGE = IntegerProperty.create("age", 0, MAX_AGE);
    public static final int STAGE_TICKS = 48000; // يومان في اللعبة

    private static final VoxelShape[] SHAPES = {
            Block.box(3, 0, 3, 13, 3, 13), Block.box(3, 0, 3, 13, 6, 13),
            Block.box(3, 0, 3, 13, 10, 13), Block.box(3, 0, 3, 13, 14, 13),
            Block.box(3, 0, 3, 13, 16, 13)};

    public CornCropBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(AGE, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(AGE);
    }

    @Override
    protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
        return SHAPES[s.getValue(AGE)];
    }

    @Override
    protected boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockState below = level.getBlockState(pos.below());
        return below.is(Blocks.FARMLAND) || below.is(ModBlocks.RICH_SOIL.get());
    }

    @Override
    protected BlockState updateShape(BlockState state, Direction dir, BlockState neighbor,
                                     LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        return !state.canSurvive(level, pos) ? Blocks.AIR.defaultBlockState()
                : super.updateShape(state, dir, neighbor, level, pos, neighborPos);
    }

    private int getDelay(LevelReader level, BlockPos pos) {
        return level.getBlockState(pos.below()).is(ModBlocks.RICH_SOIL.get()) ? STAGE_TICKS / 2 : STAGE_TICKS;
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moved) {
        if (!level.isClientSide && !old.is(this)) {
            level.scheduleTick(pos, this, getDelay(level, pos));
        }
    }

    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        int age = state.getValue(AGE);
        if (age >= MAX_AGE) return;
        if (!level.canSeeSky(pos) && level.getMaxLocalRawBrightness(pos) < 9) {
            level.scheduleTick(pos, this, 1200); // لا ضوء: أعد المحاولة بعد دقيقة
            return;
        }
        grow(level, pos, state);
        if (age + 1 < MAX_AGE) level.scheduleTick(pos, this, getDelay(level, pos));
    }

    public void grow(ServerLevel level, BlockPos pos, BlockState state) {
        int age = state.getValue(AGE);
        if (age < MAX_AGE) level.setBlock(pos, state.setValue(AGE, age + 1), 2);
    }

    // دعم عظام الطحين
    @Override
    public boolean isValidBonemealTarget(LevelReader level, BlockPos pos, BlockState state) {
        return state.getValue(AGE) < MAX_AGE;
    }

    @Override
    public boolean isBonemealSuccess(Level level, RandomSource random, BlockPos pos, BlockState state) {
        return true;
    }

    @Override
    public void performBonemeal(ServerLevel level, RandomSource random, BlockPos pos, BlockState state) {
        grow(level, pos, state);
    }
}
