package com.cornfields.block;

import com.cornfields.registry.ModBlockEntities;
import com.cornfields.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import java.util.Set;

public class FermenterBlockEntity extends BlockEntity {
    public static final int MAX_PLANTS = 8;
    public static final int FERMENT_TIME = 6000; // 5 دقائق = 6000 تك

    private static final Set<Item> EXTRA_PLANTS = Set.of(Items.WHEAT, Items.CARROT, Items.POTATO, Items.BEETROOT,
            Items.SUGAR_CANE, Items.BAMBOO, Items.KELP, Items.VINE, Items.SEAGRASS, Items.CACTUS,
            Items.PUMPKIN, Items.MELON_SLICE, Items.WHEAT_SEEDS, Items.BEETROOT_SEEDS, Items.MELON_SEEDS,
            Items.PUMPKIN_SEEDS, Items.HAY_BLOCK);

    private int plants;
    private int time;
    private boolean done;

    public FermenterBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.FERMENTER.get(), pos, state);
    }

    public static boolean isPlant(ItemStack stack) {
        if (stack.isEmpty()) return false;
        if (stack.is(ItemTags.LEAVES) || stack.is(ModItems.CORN_COB.get()) || stack.is(ModItems.CORN_SEEDS.get())) return true;
        if (EXTRA_PLANTS.contains(stack.getItem())) return true;
        return stack.getItem() instanceof BlockItem bi && bi.getBlock() instanceof BushBlock;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, FermenterBlockEntity be) {
        if (be.plants > 0 && !be.done) {
            be.time++;
            if (be.time >= FERMENT_TIME) {
                be.done = true;
                level.playSound(null, pos, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 1f, 1f);
                be.setChanged();
            } else if (be.time % 200 == 0) {
                be.setChanged();
            }
        }
    }

    public void addPlant() { plants++; setChanged(); }
    public int getPlants() { return plants; }
    public boolean isDone() { return done; }
    public int getProgressPercent() { return time * 100 / FERMENT_TIME; }
    public void reset() { plants = 0; time = 0; done = false; setChanged(); }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider reg) {
        super.saveAdditional(tag, reg);
        tag.putInt("Plants", plants);
        tag.putInt("Time", time);
        tag.putBoolean("Done", done);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider reg) {
        super.loadAdditional(tag, reg);
        plants = tag.getInt("Plants");
        time = tag.getInt("Time");
        done = tag.getBoolean("Done");
    }
}
