package com.cornfields.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;

/** تربة مسمدة: تحوّل التراب المجاور تدريجياً وتسرّع النباتات فوقها x2. */
public class RichSoilBlock extends Block {
    public RichSoilBlock(Properties props) {
        super(props);
    }

    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        // 1) الانتشار إلى التراب (Dirt) المجاور
        if (random.nextInt(3) == 0) {
            BlockPos target = pos.offset(random.nextInt(3) - 1, random.nextInt(3) - 1, random.nextInt(3) - 1);
            if (level.getBlockState(target).is(Blocks.DIRT)) {
                level.setBlockAndUpdate(target, defaultBlockState());
            }
        }
        // 2) تسريع النبات فوقها: تك عشوائي إضافي = ضعف السرعة
        BlockPos above = pos.above();
        BlockState a = level.getBlockState(above);
        Block b = a.getBlock();
        if (b instanceof CropBlock || b instanceof StemBlock || b instanceof SaplingBlock
                || b instanceof SweetBerryBushBlock || b instanceof NetherWartBlock) {
            a.randomTick(level, above, random);
        }
    }
}
