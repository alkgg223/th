package com.cornfields.block;

import com.cornfields.registry.ModBlockEntities;
import com.cornfields.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public class FermenterBlock extends Block implements EntityBlock {
    public FermenterBlock(Properties props) {
        super(props);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new FermenterBlockEntity(pos, state);
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide || type != ModBlockEntities.FERMENTER.get()) return null;
        return (lvl, p, s, be) -> FermenterBlockEntity.serverTick(lvl, p, s, (FermenterBlockEntity) be);
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.getBlockEntity(pos) instanceof FermenterBlockEntity fe
                && !fe.isDone() && fe.getPlants() < FermenterBlockEntity.MAX_PLANTS
                && FermenterBlockEntity.isPlant(stack)) {
            if (!level.isClientSide) {
                fe.addPlant();
                if (!player.getAbilities().instabuild) stack.shrink(1);
                level.playSound(null, pos, SoundEvents.COMPOSTER_FILL, SoundSource.BLOCKS, 1f, 1f);
                player.displayClientMessage(Component.translatable("message.cornfields.fermenter.added",
                        fe.getPlants(), FermenterBlockEntity.MAX_PLANTS), true);
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.getBlockEntity(pos) instanceof FermenterBlockEntity fe) {
            if (!level.isClientSide) {
                if (fe.isDone()) {
                    popResource(level, pos.above(), new ItemStack(ModItems.RICH_SOIL.get(), fe.getPlants()));
                    fe.reset();
                    level.playSound(null, pos, SoundEvents.COMPOSTER_EMPTY, SoundSource.BLOCKS, 1f, 1f);
                } else if (fe.getPlants() == 0) {
                    player.displayClientMessage(Component.translatable("message.cornfields.fermenter.empty"), true);
                } else {
                    player.displayClientMessage(Component.translatable("message.cornfields.fermenter.progress",
                            fe.getProgressPercent()), true);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }
}
