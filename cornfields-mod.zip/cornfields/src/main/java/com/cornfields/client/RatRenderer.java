package com.cornfields.client;

import com.cornfields.CornFields;
import com.cornfields.entity.Rat;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class RatRenderer extends MobRenderer<Rat, RatModel> {
    private static final ResourceLocation TEX =
            ResourceLocation.fromNamespaceAndPath(CornFields.MODID, "textures/entity/rat.png");

    public RatRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new RatModel(ctx.bakeLayer(RatModel.LAYER)), 0.25f);
    }

    @Override
    public ResourceLocation getTextureLocation(Rat rat) {
        return TEX;
    }
}
