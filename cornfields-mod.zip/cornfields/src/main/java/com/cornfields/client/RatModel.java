package com.cornfields.client;

import com.cornfields.CornFields;
import com.cornfields.entity.Rat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class RatModel extends EntityModel<Rat> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(CornFields.MODID, "rat"), "main");

    private final ModelPart root, head, tail, legFR, legFL, legBR, legBL;

    public RatModel(ModelPart root) {
        this.root = root;
        head = root.getChild("head");
        tail = root.getChild("tail");
        legFR = root.getChild("leg_fr");
        legFL = root.getChild("leg_fl");
        legBR = root.getChild("leg_br");
        legBL = root.getChild("leg_bl");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-2.5f, -2f, -4f, 5, 4, 8), PartPose.offset(0, 20, 0));
        PartDefinition h = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 12)
                .addBox(-2f, -1.5f, -4f, 4, 3, 4), PartPose.offset(0, 19.5f, -4));
        h.addOrReplaceChild("snout", CubeListBuilder.create().texOffs(0, 26)
                .addBox(-1f, -1f, -2f, 2, 2, 2), PartPose.offset(0, 0.5f, -4));
        h.addOrReplaceChild("ear_r", CubeListBuilder.create().texOffs(32, 0)
                .addBox(-1f, -2f, -0.5f, 2, 2, 1), PartPose.offset(-1.5f, -1.5f, -1));
        h.addOrReplaceChild("ear_l", CubeListBuilder.create().texOffs(32, 0)
                .addBox(-1f, -2f, -0.5f, 2, 2, 1), PartPose.offset(1.5f, -1.5f, -1));
        r.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(32, 8)
                .addBox(-0.5f, -0.5f, 0f, 1, 1, 8), PartPose.offsetAndRotation(0, 21, 4, -0.2f, 0, 0));
        CubeListBuilder leg = CubeListBuilder.create().texOffs(32, 20).addBox(-0.5f, 0f, -0.5f, 1, 2, 1);
        r.addOrReplaceChild("leg_fr", leg, PartPose.offset(-1.7f, 22, -2.5f));
        r.addOrReplaceChild("leg_fl", leg, PartPose.offset(1.7f, 22, -2.5f));
        r.addOrReplaceChild("leg_br", leg, PartPose.offset(-1.7f, 22, 2.5f));
        r.addOrReplaceChild("leg_bl", leg, PartPose.offset(1.7f, 22, 2.5f));
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(Rat e, float limbSwing, float limbSwingAmount, float age, float netHeadYaw, float headPitch) {
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        head.xRot = headPitch * Mth.DEG_TO_RAD;
        float s = limbSwing * 0.9f;
        legFR.xRot = Mth.cos(s) * 1.2f * limbSwingAmount;
        legBL.xRot = legFR.xRot;
        legFL.xRot = Mth.cos(s + Mth.PI) * 1.2f * limbSwingAmount;
        legBR.xRot = legFL.xRot;
        tail.yRot = Mth.cos(age * 0.2f) * 0.25f + Mth.cos(s) * 0.3f * limbSwingAmount;
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, int color) {
        root.render(ps, vc, light, overlay, color);
    }
}
