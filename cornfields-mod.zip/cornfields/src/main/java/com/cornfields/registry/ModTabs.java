package com.cornfields.registry;

import com.cornfields.CornFields;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredRegister;
import java.util.function.Supplier;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CornFields.MODID);

    public static final Supplier<CreativeModeTab> MAIN = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.cornfields"))
            .icon(() -> new ItemStack(ModItems.CORN_COB.get()))
            .displayItems((params, out) -> {
                out.accept(ModItems.CORN_SEEDS.get());
                out.accept(ModItems.CORN_COB.get());
                out.accept(ModItems.POPCORN.get());
                out.accept(ModItems.CORN_CHIPS.get());
                out.accept(ModItems.RAT_DROPPINGS.get());
                out.accept(ModItems.RICH_SOIL.get());
                out.accept(ModItems.FERMENTER.get());
                out.accept(ModItems.RAT_SPAWN_EGG.get());
            }).build());
}
