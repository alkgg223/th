package com.cornfields.registry;

import com.cornfields.CornFields;
import com.cornfields.entity.Rat;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(BuiltInRegistries.ENTITY_TYPE, CornFields.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<Rat>> RAT = ENTITIES.register("rat",
            () -> EntityType.Builder.of(Rat::new, MobCategory.AMBIENT)
                    .sized(0.5f, 0.4f).clientTrackingRange(8).build("rat"));

    public static void registerAttributes(EntityAttributeCreationEvent e) {
        e.put(RAT.get(), Rat.createAttributes().build());
    }

    public static void registerSpawnPlacements(RegisterSpawnPlacementsEvent e) {
        e.register(RAT.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Rat::checkRatSpawn, RegisterSpawnPlacementsEvent.Operation.REPLACE);
    }
}
