package com.cornfields.registry;

import com.cornfields.CornFields;
import com.cornfields.item.RatDroppingsItem;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemNameBlockItem;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(CornFields.MODID);

    public static final DeferredItem<Item> CORN_COB = ITEMS.registerSimpleItem("corn_cob",
            new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.4f).build()));
    public static final DeferredItem<Item> POPCORN = ITEMS.registerSimpleItem("popcorn",
            new Item.Properties().food(new FoodProperties.Builder().nutrition(4).saturationModifier(0.3f).fast().build()));
    public static final DeferredItem<Item> CORN_CHIPS = ITEMS.registerSimpleItem("corn_chips",
            new Item.Properties().food(new FoodProperties.Builder().nutrition(5).saturationModifier(0.4f).fast().build()));
    public static final DeferredItem<Item> CORN_SEEDS = ITEMS.register("corn_seeds",
            () -> new ItemNameBlockItem(ModBlocks.CORN_CROP.get(), new Item.Properties()));
    public static final DeferredItem<Item> RAT_DROPPINGS = ITEMS.register("rat_droppings",
            () -> new RatDroppingsItem(new Item.Properties()));
    public static final DeferredItem<Item> RAT_SPAWN_EGG = ITEMS.register("rat_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.RAT, 0x6B5A4A, 0xF0A0A0, new Item.Properties()));

    public static final DeferredItem<BlockItem> RICH_SOIL = ITEMS.registerSimpleBlockItem(ModBlocks.RICH_SOIL);
    public static final DeferredItem<BlockItem> FERMENTER = ITEMS.registerSimpleBlockItem(ModBlocks.FERMENTER);
}
