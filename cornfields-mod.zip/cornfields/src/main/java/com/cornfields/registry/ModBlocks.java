package com.cornfields.registry;

import com.cornfields.CornFields;
import com.cornfields.block.*;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(CornFields.MODID);

    public static final DeferredBlock<CornCropBlock> CORN_CROP = BLOCKS.registerBlock("corn_crop", CornCropBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.PLANT).noCollission().noOcclusion()
                    .instabreak().sound(SoundType.CROP).pushReaction(PushReaction.DESTROY));

    public static final DeferredBlock<RichSoilBlock> RICH_SOIL = BLOCKS.registerBlock("rich_soil", RichSoilBlock::new,
            BlockBehaviour.Properties.ofFullCopy(Blocks.DIRT).randomTicks().mapColor(MapColor.COLOR_BROWN));

    public static final DeferredBlock<FermenterBlock> FERMENTER = BLOCKS.registerBlock("fermenter", FermenterBlock::new,
            BlockBehaviour.Properties.ofFullCopy(Blocks.BARREL));
}
