package com.cornfields.entity;

import com.cornfields.block.CornCropBlock;
import com.cornfields.registry.ModBlocks;
import com.cornfields.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import java.util.EnumSet;

public class Rat extends PathfinderMob {
    private int droppingTimer;

    public Rat(EntityType<? extends Rat> type, Level level) {
        super(type, level);
        droppingTimer = 3000 + random.nextInt(3000);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 6.0).add(Attributes.MOVEMENT_SPEED, 0.3);
    }

    /** يظهر الجرذ فقط إذا وُجدت ذرة ضمن 8 بلوكات. */
    public static boolean checkRatSpawn(EntityType<Rat> type, ServerLevelAccessor level, MobSpawnType reason,
                                        BlockPos pos, RandomSource random) {
        for (BlockPos p : BlockPos.betweenClosed(pos.offset(-8, -3, -8), pos.offset(8, 3, 8))) {
            if (level.getBlockState(p).is(ModBlocks.CORN_CROP.get())) return true;
        }
        return false;
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new PanicGoal(this, 1.5));
        goalSelector.addGoal(2, new AvoidEntityGoal<>(this, Player.class, 5f, 1.0, 1.4));
        goalSelector.addGoal(3, new GoToCornGoal(this));
        goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 6f));
        goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!level().isClientSide && isAlive() && --droppingTimer <= 0) {
            droppingTimer = 3000 + random.nextInt(3000);
            produceDroppings();
        }
    }

    /** قرب الذرة: يسمّدها مباشرة. بعيداً عنها: يُسقط فضلات يمكن جمعها. */
    private void produceDroppings() {
        BlockPos near = findCorn(4, true);
        if (near != null && level() instanceof ServerLevel sl) {
            BlockState st = sl.getBlockState(near);
            ((CornCropBlock) st.getBlock()).grow(sl, near, st);
            sl.levelEvent(1505, near, 15);
            return;
        }
        spawnAtLocation(ModItems.RAT_DROPPINGS.get());
    }

    BlockPos findCorn(int r, boolean growableOnly) {
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        BlockPos me = blockPosition();
        for (BlockPos p : BlockPos.betweenClosed(me.offset(-r, -2, -r), me.offset(r, 2, r))) {
            BlockState st = level().getBlockState(p);
            if (st.is(ModBlocks.CORN_CROP.get())
                    && (!growableOnly || st.getValue(CornCropBlock.AGE) < CornCropBlock.MAX_AGE)) {
                double d = p.distSqr(me);
                if (d < bestD) { bestD = d; best = p.immutable(); }
            }
        }
        return best;
    }

    @Override protected SoundEvent getAmbientSound() { return SoundEvents.SILVERFISH_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.SILVERFISH_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.SILVERFISH_DEATH; }

    static class GoToCornGoal extends Goal {
        private final Rat rat;
        private BlockPos target;

        GoToCornGoal(Rat rat) {
            this.rat = rat;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (rat.getRandom().nextInt(60) != 0) return false;
            target = rat.findCorn(10, false);
            return target != null && rat.blockPosition().distSqr(target) > 4;
        }

        @Override
        public boolean canContinueToUse() {
            return target != null && !rat.getNavigation().isDone();
        }

        @Override
        public void start() {
            rat.getNavigation().moveTo(target.getX() + 0.5, target.getY(), target.getZ() + 0.5, 1.0);
        }
    }
}
