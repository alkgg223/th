package com.cornfields.item;

import com.cornfields.block.CornCropBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** فضلات الجرذ: سماد، يقدّم الذرة مرحلة واحدة (مثل عظام الطحين). */
public class RatDroppingsItem extends Item {
    public RatDroppingsItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        BlockPos pos = ctx.getClickedPos();
        BlockState st = level.getBlockState(pos);
        if (st.getBlock() instanceof CornCropBlock corn && st.getValue(CornCropBlock.AGE) < CornCropBlock.MAX_AGE) {
            if (level instanceof ServerLevel sl) {
                corn.grow(sl, pos, st);
                ctx.getItemInHand().shrink(1);
                sl.levelEvent(1505, pos, 15);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }
}
