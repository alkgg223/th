طريقة التشغيل:
1) حمّل NeoForge MDK لإصدار 1.21.1 (github.com/NeoForgeMDKs/MDK-1.21.1-ModDevGradle).
2) انسخ مجلد src/ من هذا المشروع فوق src/ في MDK (احذف ملفات المثال القديمة: ExampleMod.java ...).
3) ضع قيم gradle.properties.example داخل gradle.properties (neo_version=21.1.264).
4) شغّل: ./gradlew runClient   للتجربة   |   ./gradlew build   لإنتاج الـ jar في build/libs
الصور (textures) مؤقتة، استبدلها بصورك بنفس الأسماء والمسارات.
